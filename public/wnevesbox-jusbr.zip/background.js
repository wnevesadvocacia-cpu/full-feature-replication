importScripts('core.js');
const appOrigins = new Set(['https://wnevesbox.com', 'https://www.wnevesbox.com', 'https://full-feature-replication.lovable.app', 'https://id-preview--b753a021-ff4f-4e59-b4fd-f9f912a4c7bf.lovable.app']);
const origin = sender => { try { return new URL(sender.url).origin; } catch { return ''; } };
let processing = false;
let serial = Promise.resolve();
function exclusive(fn) { const task = serial.then(fn); serial = task.catch(() => {}); return task; }
async function status(message) {
  await chrome.storage.local.set({ message });
  await chrome.action.setBadgeText({ text: '!' });
}
async function pump() {
  if (processing) return;
  processing = true;
  try {
    const state = await chrome.storage.local.get(['owner','tabId','queue','origin']);
    const item = state.queue?.find(q => q.owner === state.owner && q.retryAt <= Date.now());
    if (!item) return;
    try {
      const tab = await chrome.tabs.get(state.tabId);
      if (!tab.url || new URL(tab.url).origin !== state.origin) throw Error('Abra Intimações na conta vinculada para retomar.');
      const result = await chrome.tabs.sendMessage(state.tabId, { type: 'CHECK_BATCH', owner: state.owner, batch: item });
      if (!result?.ok || !result.persisted) throw Error(result?.message || 'Lote sem confirmação do servidor.');
      if (result.done) {
        await exclusive(async () => {
          const latest = await chrome.storage.local.get(['owner','queue']);
          if (latest.owner !== item.owner) return;
          await chrome.storage.local.set(JusbrCore.acknowledge(latest, item.owner, item.id));
        });
        await status(result.message);
      } else {
        await exclusive(async () => {
          const latest = await chrome.storage.local.get(['owner','queue']);
          if (latest.owner !== item.owner) return;
          await chrome.storage.local.set({ queue: (latest.queue || []).map(q => q.id === item.id ? { ...q, retryAt: Date.now() + 60000 } : q) });
        });
        await status(result.message);
      }
    } catch (e) {
      await exclusive(async () => {
        const latest = await chrome.storage.local.get(['owner','queue']);
        if (latest.owner !== item.owner) return;
        await chrome.storage.local.set({ queue: (latest.queue || []).map(q => q.id === item.id ? JusbrCore.retry(q, Date.now()) : q) });
      });
      await status(`${e.message} Retentativa automática; importações preservadas.`);
    }
  } finally {
    processing = false;
    const state = await chrome.storage.local.get('queue');
    if (state.queue?.length) await chrome.alarms.create('retry', { when: Math.max(Date.now() + 60000, Math.min(...state.queue.map(q => q.retryAt || 0))) });
    else await chrome.alarms.clear('retry');
  }
}
async function scan() {
  const state = await chrome.storage.local.get(['owner','settings','lastCompleteEnd']);
  if (!state.owner) return;
  const tabs = await chrome.tabs.query({ url: 'https://portaldeservicos.pdpj.jus.br/*' });
  if (!tabs.length) return status('Jus.br não está aberto. Faça login no portal; credenciais nunca são capturadas.');
  for (const tab of tabs) {
    try { await chrome.tabs.sendMessage(tab.id, { type: 'SCAN', window: JusbrCore.window(state.lastCompleteEnd), settings: state.settings }); }
    catch { await status('Recarregue a Central Jus.br. Estrutura/sessão não verificada.'); }
  }
}
chrome.runtime.onMessage.addListener((m, sender, reply) => {
  exclusive(async () => {
    if (['PAIR','RESTORE'].includes(m.type)) {
      if (!appOrigins.has(origin(sender)) || !sender.tab || !/^[0-9a-f-]{36}$/i.test(m.owner || '')) throw Error('Vínculo inválido.');
      const state = await chrome.storage.local.get(['owner','queue']);
      if (m.type === 'RESTORE' && state.owner !== m.owner) return { ok: false };
      if (state.owner && state.owner !== m.owner && state.queue?.length) throw Error('Há lotes da conta anterior. Retome nessa conta antes de trocar o vínculo.');
      await chrome.storage.local.set({ owner: m.owner, tabId: sender.tab.id, origin: origin(sender), settings: m.settings, ...(state.owner !== m.owner ? { queue: [], lastCompleteEnd: null } : {}) });
      await chrome.alarms.create('scan', { periodInMinutes: 60 });
      await status('Vínculo persistido. Pesquisa/paginação reais aguardam validação dos controles.');
      return { ok: true, owner: m.owner };
    }
    if (origin(sender) !== 'https://portaldeservicos.pdpj.jus.br') throw Error('Origem inválida.');
    if (m.type === 'PORTAL_STATUS') {
      await status(String(m.message || 'Estrutura desconhecida.').slice(0, 400));
      return { ok: true };
    }
    if (m.type !== 'JUSBR_BATCH' || !Array.isArray(m.batch?.rows) || m.batch.rows.length > 100) throw Error('Lote inválido.');
    const state = await chrome.storage.local.get(['owner','queue']);
    if (!state.owner) throw Error('Vincule a extensão no WnevesBox uma vez.');
    await chrome.storage.local.set(JusbrCore.enqueue(state, state.owner, m.batch));
    await chrome.alarms.create('retry', { delayInMinutes: 1 });
    return { ok: true, queued: true };
  }).then(result => { reply(result); void pump(); if (['PAIR','RESTORE'].includes(m.type) && result.ok) void scan(); })
    .catch(async e => { await status(e.message); reply({ ok: false, message: e.message }); });
  return true;
});
chrome.alarms.onAlarm.addListener(alarm => { if (alarm.name === 'retry') void pump(); if (alarm.name === 'scan') void scan(); });
chrome.runtime.onStartup.addListener(() => { void pump(); void scan(); });
